*** Settings ***
Library SeleniumLibrary

*** Variables ***
${BROWSER}  Chrome
${URL}  https://www.google.com
${CAMPO_BUSCA}  Name:q
${TERMO_BUSCA}  Nike Force
${RESULTADO_SELECTOR}   css:li.b_algo

*** Keywords ***
Abrir o navegador
    Open Browser    ${URL} ${BROWSER}
    Maximize Browser Window

Acessar a pagina home do site
    Go To   url=${URL}
    Wait Until Page Contains Element    ${CAMPO_BUSCA}  timeout=10s

Realizar pesquisa no site
    Input Text ${CAMPO_BUSCA}   ${TERMO_BUSCA}
    Press Keys ${CAMPO_BUSCA}   RETURN
    Wait Until Page Contains Element    ${RESULTADO_SELECTOR}   timeout=10s

Verificar resultado da busca
    Page Should Contain ${TERMO_BUSCA}

Fechar navegador
    Capture Page Screenshot
    Close Browser