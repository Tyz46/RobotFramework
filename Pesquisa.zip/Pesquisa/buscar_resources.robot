*** Settings ***
Library     SeleniumLibrary

*** Variables ***
${BROWSER}  Chrome
${URL}  http://165.227.93.41/lojinha-web/

${CAMPO_LOGIN}  name=usuario
${TERMO_LOGIN}  rafael

${CAMPO_SENHA}  name=senha
${TERMO_SENHA}  123456

*** Keywords ***
Abrir o navegador
    Open Browser    ${URL}  ${BROWSER}
    Maximize Browser Window

Acessar a pagina home do site
    Go To   url=${URL}
    Wait Until Page Contains Element    ${CAMPO_LOGIN}  timeout=20s
    Wait Until Page Contains Element    ${CAMPO_SENHA}  timeout=20s

Preencher campo usuario
    Input Text  ${CAMPO_LOGIN}   ${TERMO_LOGIN}
    Press Keys  ${CAMPO_LOGIN}   RETURN
    Wait Until Page Contains Element    ${RESULTADO_SELECTOR}   timeout=10s

Preencher campo senha
    Input Text  ${CAMPO_SENHA}   ${TERMO_SENHA}
    Press Keys  ${CAMPO_SENHA}   RETURN
    Wait Until Page Contains Element    ${RESULTADO_SELECTOR}   timeout=10s

Fechar navegador
    Capture Page Screenshot
    Close Browser