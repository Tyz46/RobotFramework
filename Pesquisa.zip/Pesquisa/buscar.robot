*** Settings ***
Resource    buscar_resources.robot
Test Setup  Abrir o navegador
Test Teardown   Fechar navegador

*** Test Cases ***
CT1 - Realizar login na Lojinha
    [Tags]  login_lojinha
    Acessar a pagina home do site
    Preencher campo usuario
    Preencher campo senha